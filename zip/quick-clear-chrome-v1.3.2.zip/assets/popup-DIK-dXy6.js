import{c as r,j as t,r as e,A as o}from"./App-69lDCjRI.js";import"./chrome-api-CYyKVbCV.js";r.createRoot(document.getElementById("root")).render(t.jsx(e.StrictMode,{children:t.jsx(o,{})}));
