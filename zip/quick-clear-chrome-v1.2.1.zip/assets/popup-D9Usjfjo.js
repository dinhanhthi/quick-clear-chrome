import{c as r,j as t,r as e,A as o}from"./App-C8PhZmc7.js";import"./chrome-api-B_CZChi2.js";r.createRoot(document.getElementById("root")).render(t.jsx(e.StrictMode,{children:t.jsx(o,{})}));
